﻿namespace RouteMobile.Consumer.Models
{
    public class file_contents
    {
        public int id { get; set; }
        public string username { get; set; }
        public string email_address { get; set; }
        public string city { get; set; }
        public DateTime created_on { get; set; }
        public file_contents(string username, string email_address, string city, DateTime created_on)
        {
            this.username = username;
            this.email_address = email_address;
            this.city = city;
            this.created_on = created_on;
        }
    }
}
