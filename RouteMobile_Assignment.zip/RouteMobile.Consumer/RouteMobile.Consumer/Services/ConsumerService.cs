﻿using Npgsql;
using RabbitMQ.Client.Events;
using RabbitMQ.Client;
using System.Text;
using RouteMobile.Consumer.Data;
using Microsoft.EntityFrameworkCore;
using RouteMobile.Consumer.Models;

namespace RouteMobile.Consumer.Services
{
    public class ConsumerService
    {
        private IConnection _connection;
        private IModel _channel;
        private readonly IConfiguration _configuration;
        string postgre_conn = "";
        private ConsumerDbContext _context;

        string tableName = "file_contents";

        public List<string> Messages { get; } = new List<string>();
        public ConsumerService(IConfiguration _configuration)
        {
            this._configuration = _configuration;
            postgre_conn = _configuration.GetConnectionString("DefaultConnection");
            Console.WriteLine("File system");
            var factory = new ConnectionFactory
            {
                HostName = "localhost"
            };
            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();
            _channel.QueueDeclare("demo-queue",
                durable: true,
                exclusive: false,
                autoDelete: false,
                arguments: null
            );
        }
        public void ReceiveMessages()
        {
            var consumer = new EventingBasicConsumer(_channel);
            consumer.Received += async (sender, e) =>
            {
                var body = e.Body.ToArray();
                var msg = Encoding.UTF8.GetString(body);
                Messages.Add(msg);
                string[] dataArray = msg.Split(',');

                //Save to database
                SaveToDb(dataArray);

                Console.WriteLine($"Processed: {msg}");

                // Apply rate limiting to 30 requests per second
                Thread.Sleep(33); // 1000ms / 30 requests = ~33ms per request
            };
            _channel.BasicConsume("demo-queue", true, consumer);

        }

        public void SaveToDb(string[] dataArray)
        {
            using (var conn = new NpgsqlConnection(postgre_conn))
            {
                conn.Open();

                // Insert the data into the database
                using (var cmd = new NpgsqlCommand("INSERT INTO " + tableName 
                    + " (username, email_address, city, created_on) " 
                    + "VALUES " 
                    + "(@Username, @EmailAddress, @City, @CreatedOn)", conn))
                {
                    cmd.Parameters.AddWithValue("Username", dataArray[0]);
                    cmd.Parameters.AddWithValue("EmailAddress", dataArray[1]);
                    cmd.Parameters.AddWithValue("City", dataArray[2]);
                    cmd.Parameters.AddWithValue("CreatedOn", DateTime.Parse(dataArray[3]));
                    cmd.ExecuteNonQuery();
                }
                conn.Close();
            }
        }
        public void StopListening()
        {
            _channel.Close();
            _connection.Close();
        }
    }
}
