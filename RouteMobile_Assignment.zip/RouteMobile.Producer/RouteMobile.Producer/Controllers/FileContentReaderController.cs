﻿using Microsoft.AspNetCore.Mvc;
using RabbitMQ.Client;
using System.Text;

namespace RouteMobile.Producer.Controllers
{
    public class FileContentReaderController : Controller
    {
        [HttpGet]
        public IActionResult UploadFile()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                // check for file extension
                string extension = file.FileName.Substring(file.FileName.LastIndexOf(".") + 1);
                if (!extension.ToUpper().Equals("TXT") && !extension.ToUpper().Equals("CSV"))
                {
                    ViewBag.Color = "RED";
                    ViewData["Message"] = "Please select .txt or .csv file";
                }
                else
                {
                    // Specify a path to save the uploaded file
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", file.FileName);

                    // Ensure the uploads directory exists
                    Directory.CreateDirectory(Path.GetDirectoryName(filePath));

                    // Save the file to the server
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    //Reading file contents line by line
                    ReadFileContents(filePath);

                    ViewBag.Color = "GREEN";
                    ViewData["Message"] = "File uploaded successfully!";
                }
            }
            else
            {
                ViewBag.Color = "RED";
                ViewData["Message"] = "No file selected.";
            }

            return View();
        }

        /**
         * Function to read uploaded file contents and send message to queue
         */
        public void ReadFileContents(string filepath)
        {
            var factory = new ConnectionFactory
            {
                HostName = "localhost"
            };
            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();
            channel.QueueDeclare("demo-queue",
                durable: true,
                exclusive: false,
                autoDelete: false,
                arguments: null
            );

            string[] lines = System.IO.File.ReadAllLines(filepath);

            // Publish the message to the exchange
            foreach (string line in lines)
            {
                var body = Encoding.UTF8.GetBytes(line);

                channel.BasicPublish("", "demo-queue", null, body);

                Console.WriteLine($"Sent: {line}");
            }

            Console.WriteLine($"Published total : {lines.Length} messages.");
        }
    }
}
