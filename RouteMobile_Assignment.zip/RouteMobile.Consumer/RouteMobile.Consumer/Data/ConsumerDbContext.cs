﻿using Microsoft.EntityFrameworkCore;
using RouteMobile.Consumer.Models;

namespace RouteMobile.Consumer.Data
{
    public class ConsumerDbContext : DbContext
    {
        public ConsumerDbContext(DbContextOptions<ConsumerDbContext> options) : base(options) { }
        public DbSet<file_contents> FileContent { get; set; }
    }
}
