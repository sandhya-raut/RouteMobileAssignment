﻿using Microsoft.AspNetCore.Mvc;
using Npgsql;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

namespace RouteMobile.Consumer.Controllers
{
    public class ConsumerController : Controller
    {
        private readonly IConfiguration _configuration;
        string postgre_conn = "";
        public List<string> Messages = new List<string>();
        public ConsumerController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            postgre_conn = _configuration.GetConnectionString("DefaultConnection");
            Consume();
            ViewBag.Message = "Processed messages successfully";
            return View(Messages);
        }

        public  void Consume()
        {

            Console.WriteLine("File system");
            var factory = new ConnectionFactory
            {
                HostName = "localhost"
            };
            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();
            channel.QueueDeclare("demo-queue",
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: null
            );
            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (sender, e) =>
            {
                var body = e.Body.ToArray();
                var msg = Encoding.UTF8.GetString(body);
                var reader = new StringReader(msg);
                // var csv = new CsvReader(reader);
                //  var records = csv.GetRecords<FileContent>();
                //  var d = records.FirstOrDefault();
                Messages.Add(msg);
                string[] dataArray = msg.Split(',');

                //Save to database
                SaveToDb(dataArray);

                Console.WriteLine($"Processed: {msg}");

                // Apply rate limiting to 30 requests per second
                Thread.Sleep(33); // 1000ms / 30 requests = ~33ms per request

            };
            channel.BasicConsume("demo-queue", true, consumer);

            //Console.ReadLine();

        }

        public void SaveToDb(string[]  dataArray)
        {
            using (var conn = new NpgsqlConnection(postgre_conn))
            {
                conn.Open();

                // Insert the data into the database
                using (var cmd = new NpgsqlCommand("INSERT INTO filecontents (username,emailaddress,city,createdon) VALUES (@Username,@EmailAddress,@City,@CreatedOn)", conn))
                {
                    cmd.Parameters.AddWithValue("Username", dataArray[0]);
                    cmd.Parameters.AddWithValue("EmailAddress", dataArray[1]);
                    cmd.Parameters.AddWithValue("City", dataArray[2]);
                    cmd.Parameters.AddWithValue("CreatedOn", DateTime.Parse(dataArray[3]));
                    cmd.ExecuteNonQuery();
                }
                conn.Close();
            }
        }
    }
}
