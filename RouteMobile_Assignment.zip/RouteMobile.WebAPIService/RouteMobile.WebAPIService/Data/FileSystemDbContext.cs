﻿using Microsoft.EntityFrameworkCore;
using RouteMobile.WebAPIService.Models;

namespace RouteMobile.WebAPIService.Data
{
    public class FileSystemDbContext : DbContext
    {
        public FileSystemDbContext(DbContextOptions<FileSystemDbContext> options) : base(options) { }
        public DbSet<file_contents> file_contents { get; set; }
    }
}
