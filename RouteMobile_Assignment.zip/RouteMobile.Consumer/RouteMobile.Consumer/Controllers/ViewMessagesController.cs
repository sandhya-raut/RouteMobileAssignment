﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RouteMobile.Consumer.Data;
using RouteMobile.Consumer.Models;
using RouteMobile.Consumer.Services;
using System.Text;
using System.Threading.Channels;

namespace RouteMobile.Consumer.Controllers
{
    public class ViewMessagesController : Controller
    {
        private readonly ConsumerService _consumerService;
        private readonly ConsumerDbContext _context;

        public ViewMessagesController(ConsumerService _consumerService, ConsumerDbContext _context)
        {

            this._consumerService = _consumerService;

            this._context = _context;

        }
        public IActionResult Index()
        {
            ViewBag.TotalCount = _consumerService.Messages.Count;
            return View(_consumerService.Messages);
        }
    }
}
