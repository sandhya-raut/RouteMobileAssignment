﻿namespace RouteMobile.WebAPIService.Models
{
    public class PaginatedResponse<T>
    {
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages { get; set; }
        public IEnumerable<T> Data { get; set; }

        public PaginatedResponse(int pageNo, int pageSize, int totalCount, IEnumerable<T> data)
        {
            PageNo = pageNo;
            PageSize = pageSize;
            TotalCount = totalCount;
            if (totalCount % pageSize != 0)
            {
                TotalPages = (totalCount / pageSize) + 1;
            }
            else
            {
                TotalPages = totalCount / pageSize;
            }
            Data = data;
        }
    }
}
