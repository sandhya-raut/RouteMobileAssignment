﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RouteMobile.WebAPIService.Data;
using RouteMobile.WebAPIService.Models;

namespace RouteMobile.WebAPIService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContentReaderController : ControllerBase
    {
        private readonly FileSystemDbContext _context;
        public ContentReaderController(FileSystemDbContext _context)
        {
            this._context = _context;
        }
        [HttpGet]
        public async Task<IActionResult> GetValues([FromQuery] int pageno,
                                                      [FromQuery] int pagesize,
                                                      [FromQuery] string name)
        {
            //We can use cache if required
            var query = _context.file_contents.AsQueryable();

            if (!string.IsNullOrEmpty(name))
            {
                query = query.Where(d => d.username.Contains(name));
            }
            // query all records in single page if pagesize =0
            if (pagesize == 0)
            {
                pagesize = query.Count();
            }
            if (pageno == 0)
            {
                pageno = 1;
            }

            var dataRes = await query.Skip((pageno - 1) * pagesize)
                                  .Take(pagesize)
                                  .ToListAsync<file_contents>();

            var response = new PaginatedResponse<file_contents>(pageno, pagesize, query.Count(), dataRes);

            return Ok(response);
        }
    }
}
