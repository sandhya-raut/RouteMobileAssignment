﻿namespace RouteMobile.WebAPIService.Models
{
    public class file_contents
    {
        public int id { get; set; }
        public string username { get; set; }
        public string email_address { get; set; }
        public string city { get; set; }
        public DateTime created_on { get; set; }
    }
}
